/******************************************************************************
 * Product: Adempiere ERP & CRM Smart Business Solution                       *
 * This program is free software; you can redistribute it and/or modify it    *
 * under the terms version 2 of the GNU General Public License as published   *
 * by the Free Software Foundation. This program is distributed in the hope   *
 * that it will be useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
 * See the GNU General Public License for more details.                       *
 * You should have received a copy of the GNU General Public License along    *
 * with this program; if not, write to the Free Software Foundation, Inc.,    *
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.                     *
 * For the text or an alternative of this public license, you may reach us    *
 * Copyright (C) 2003-2012 e-Evolution,SC. All Rights Reserved.               *
 * Contributor(s): victor.perez@e-evolution.com www.e-evolution.com   		  *
 *****************************************************************************/

package org.forecasting.maximea.engine;

import java.util.Enumeration;
import java.util.Hashtable;

/**
 * DataSet
 * 
 * @author victor.perez@e-evolution.com, www.e-Evolution.com
 **/
public class DataSet {

	Hashtable<Integer, DataElement> dataset = new Hashtable<Integer, DataElement>();
	private int periods = 0;

	public void addDataElement(DataElement data) {
		dataset.put(data.getPeriodNo(), data);
	}

	public DataElement getDataElement(String key) {
		return dataset.get(key);
	}

	public Enumeration<DataElement> getDataElements() {
		return dataset.elements();
	}

	public int size() {
		return this.dataset.size();
	}
	
	public void setPeriods(int periods)
	{
		this.periods = periods;
	}
	
	public int getPeriods()
	{
		return this.periods;
	}
}
