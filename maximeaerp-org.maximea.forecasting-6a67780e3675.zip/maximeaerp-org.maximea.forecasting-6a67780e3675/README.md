org.maximea.forecasting
=============

Description
-----------
{Sales Forecasting}


Features
--------
- Repository: {https://bitbucket.org/pshepetko/org.maximea.forecasting}
- License: GPL 2
- Version: {1.0.1}


Contributors
------------
- {2018} {Maximea.pl} <maximea@maximea.pl>.


Documentation
-------------
- https://bitbucket.org/maximeaerp/org.maximea.forecasting/downloads/SalesForecasting_v1.0.1.pdf